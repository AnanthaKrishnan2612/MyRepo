package com.flightapp.bookings.model;

public enum TypeOfMeal {
	
	NON_VEG,VEG

}
