package com.flightapp.flights.model;

public enum TypeOfMeal {
	
	NON_VEG,VEG

}
