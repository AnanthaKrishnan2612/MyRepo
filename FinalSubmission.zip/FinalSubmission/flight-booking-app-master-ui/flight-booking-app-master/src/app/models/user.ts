import { FormControl, FormGroup, Validators } from "@angular/forms";

export class User{
    public username:string ='';
    public password: string = '';
    public email:string='';
    
    constructor(  
    ){
        this.username = this.username;
        this.password = this.password;
        this.email = this.email;
    }
        

}