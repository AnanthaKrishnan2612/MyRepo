import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingnavbar',
  templateUrl: './bookingnavbar.component.html',
  styleUrls: ['./bookingnavbar.component.scss']
})
export class BookingnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
